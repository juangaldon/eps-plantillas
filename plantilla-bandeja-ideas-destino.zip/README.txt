PLANTILLA · BANDEJA DE IDEAS + DESTINO

Esta plantilla sirve para:
- Vaciar ideas rápidamente
- Evitar acumular ruido mental
- Dar destino a cada idea sin pensarlo demasiado

INSTRUCCIONES:
1. Usa primero la sección BANDEJA DE IDEAS.
2. No ordenes ni filtres mientras escribes.
3. Luego pasa cada idea a su DESTINO correspondiente.
4. No intentes completarlo todo en una sesión.

Regla clave:
Si una idea no tiene destino, vuelve a la bandeja.
