# BANDEJA DE IDEAS + DESTINO

## BANDEJA DE IDEAS
_Escribe aquí todo sin pensar_

- 
- 
- 
- 

---

## DESTINO DE IDEAS

### 🧩 TAREAS (una acción)
- 

### 🧱 PROYECTOS (varios pasos)
- 

### ⏳ IDEAS EN ESPERA
- 

### 🗒 NOTAS / REFERENCIAS
- 
