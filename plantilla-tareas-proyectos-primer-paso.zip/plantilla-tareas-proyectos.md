# PLANTILLA · TAREAS (1 PASO) + PROYECTOS (PRIMER PASO)

**Regla clave**  
Si algo no se puede hacer en una sola acción, **no es una tarea**.

---

## ✅ TAREAS · UNA SOLA ACCIÓN
- 
- 
- 
- 
- 

---

## 🧱 PROYECTOS · VARIOS PASOS

### Proyecto
- **Nombre**:
- **Qué significa “terminado”**:
- **Primer paso concreto**:
- **Estado**: activo / en espera

### Proyecto
- **Nombre**:
- **Qué significa “terminado”**:
- **Primer paso concreto**:
- **Estado**: activo / en espera

---

## 🗒 NOTAS
- 
- 
