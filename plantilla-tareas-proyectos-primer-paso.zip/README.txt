PLANTILLA · TAREAS (1 PASO) + PROYECTOS (PRIMER PASO)

Esta plantilla está pensada para:
- Evitar listas interminables
- Separar tareas reales de proyectos
- Empezar proyectos sin bloquearte

REGLA CLAVE:
Si algo no se puede hacer en una sola acción, NO es una tarea.

USO RECOMENDADO:
1. Anota primero las tareas reales.
2. Todo lo demás debe pasar a proyectos.
3. En proyectos, define SOLO el primer paso.
4. No intentes planificar todo el proyecto.
